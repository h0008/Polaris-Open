module.exports = {
metadata: {
    name: "View on leaderboard",
    slashEquivalent: "top"
}
}