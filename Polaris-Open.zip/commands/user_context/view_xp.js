module.exports = {
metadata: {
    name: "Check XP",
    slashEquivalent: "rank"
}
}